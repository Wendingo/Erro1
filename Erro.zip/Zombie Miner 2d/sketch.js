
var bg;
var bgs;

function preLoad(){
    bg = loadImage("imgs/Background.png");
}

function setup(){
    createCanvas(windowWidth, windowHeight);
    bgs = createSprite(0, 0);
}

function draw(){
    background("Black");

}